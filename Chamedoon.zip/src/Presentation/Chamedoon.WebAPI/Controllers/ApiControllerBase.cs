﻿using Microsoft.AspNetCore.Mvc;

namespace Chamedoon.WebAPI.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class ApiControllerBase : ControllerBase
    {

    }
}
