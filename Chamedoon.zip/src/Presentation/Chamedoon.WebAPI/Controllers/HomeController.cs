﻿//using Chamedoon.Application.Services.Account.Users.Query;
//using MediatR;
//using Microsoft.AspNetCore.Mvc;

//namespace Chamedoon.WebAPI.Controllers
//{
//    public class HomeController : ApiControllerBase
//    {
//        [HttpGet]
//        public async Task<IActionResult> Index()
//        {
//            return Ok(); 
//        }
//    }
//}
