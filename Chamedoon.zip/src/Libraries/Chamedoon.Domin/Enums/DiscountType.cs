namespace Chamedoon.Domin.Enums;

public enum DiscountType
{
    Percentage = 0,
    FixedAmount = 1
}
