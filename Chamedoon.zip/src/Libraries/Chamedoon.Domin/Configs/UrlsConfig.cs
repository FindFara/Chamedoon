﻿namespace Chamedoon.Domin.Configs;

public class UrlsConfig
{
    public string AppUrl { get; set; }
}
