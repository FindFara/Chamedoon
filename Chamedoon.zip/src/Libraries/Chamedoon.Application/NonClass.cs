﻿using Chamedoon.Application.Common.Interfaces;
using Chamedoon.Application.Common.Models;
using Chamedoon.Domin.Base;
using MediatR;

namespace Chamedoon.Application;

//public class NonClass : IRequest<OperationResult<bool>>
//{
//}
//public class Handler : IRequestHandler<NonClass, OperationResult<bool>>
//{
//    #region Property
//    private readonly IApplicationDbContext _context;
//    #endregion

//    #region Ctor
//    public Handler(IApplicationDbContext context)
//    {
//        _context = context;
//    }
//    #endregion

//    #region Method
//    public async Task<OperationResult<bool>> Handle(NonClass request, CancellationToken cancellationToken)
//    {
//        return OperationResult<bool>.Success(true);
//    }

//    #endregion
//}


